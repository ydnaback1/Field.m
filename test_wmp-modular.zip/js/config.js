const CONFIG = {
    apiKey: 'NAI9sZS6RxIdV4MpIdHfHR9lbQ9OPOwa',
    serviceUrl: 'https://api.os.uk/maps/raster/v1/zxy'
};